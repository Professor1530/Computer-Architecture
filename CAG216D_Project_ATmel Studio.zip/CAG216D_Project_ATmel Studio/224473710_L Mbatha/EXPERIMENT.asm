ORG 0000H         ; Start of code memory

START:  
    MOV R0, #00H  ; R0 will be used as offset (0 to 9)
    MOV R2, #0AH  ; R2 = 10 bytes to copy

TRANSFER_LOOP:
    ; Load source address = 8000H + R0
    MOV DPH, #080H
    MOV DPL, R0
    MOVX A, @DPTR     ; Read from external memory at 8000H + offset
    MOV R3, A         ; Save data temporarily

    ; Load destination address = 9000H + R0
    MOV DPH, #090H
    MOV DPL, R0
    MOV A, R3
    MOVX @DPTR, A     ; Write to external memory at 9000H + offset

    INC R0            ; Move to next byte
    DJNZ R2, TRANSFER_LOOP  ; Repeat until 10 bytes copied

    SJMP $            ; End of program (infinite loop)

END                   ; Required directive for assembler
